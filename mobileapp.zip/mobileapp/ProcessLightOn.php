        <?php 
        include '../inc.php';
        
  
        header("Content-Type: application/json");
        class clsListData
        {
        public $ResponsiblePerson;
        public $Count;
            public $nameid;
        
        }
        $listArray=array();
        $dateo=Date('Y-m-d', strtotime('+14 days')); 
        $rs1=GetPageRecord('responsiblity,COUNT(responsiblity) as rescount','timeActionReport','1 and complitionDate>"'.date('Y-m-d').'" and complitionDate<"'.$dateo.'"  and taskListId in (select id from taskListMaster where tna=1) and responsiblity!="" group by responsiblity order by complitionDate asc'); 
        while($data=mysql_fetch_array($rs1)){ 
        						
        
        // $rs1s=GetPageRecord('COUNT(responsiblity) as rescount','timeActionReport','1 and responsiblity="'.$data['responsiblity'].'"'); 
        // $datas=mysql_fetch_array($rs1s); 
        						
        
        
        $objListData = new clsListData();
        $objListData->ResponsiblePerson = getEmployeeName($data['responsiblity']);
        $objListData->Count =$data['rescount'];
        $objListData->nameid =$data['responsiblity'];
        
        array_push($listArray, $objListData);
        
        } 
        
        echo json_encode(['Status'=>'0','Message'=>'Success','TotalRecord'=>$listArray],JSON_PRETTY_PRINT);
        
        
        ?>