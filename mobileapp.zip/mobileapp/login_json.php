<?php 
include '../inc.php';




header("Content-Type: application/json");
$parameterdata = file_get_contents('php://input');



$dataToShare = json_decode($parameterdata);

$userId=$dataToShare->username;

$password=md5($dataToShare->userpass);




$select='id,email,firstName,lastName,profileId'; 

$where='email="'.$userId.'" and password="'.$password.'"'; 
$rs=GetPageRecord($select,_USER_MASTER_,$where); 
$countrows=mysql_num_rows($rs); 




if($countrows>0){

$userinfoList = mysql_fetch_assoc($rs);


$resultlist = $userinfoList;
$jsonData = json_encode($resultlist,JSON_PRETTY_PRINT);

echo $jsonData;
}
else{
echo $jsonData = json_encode('Invalid Credentials',JSON_PRETTY_PRINT);

 }
?>