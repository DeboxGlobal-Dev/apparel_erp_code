<?php
session_start();
include "db.php";
$id = $_GET['id'];
$del = "DELETE FROM `form` WHERE id = '".$id."'";
$result = mysqli_query($conn, $del);
if($result){
    $_SESSION['status']="Data deteted successfuly";
    header('location:main.php');
    }else{

}

?>