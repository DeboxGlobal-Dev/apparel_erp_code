<?php 
include("db.php");
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.2.1/css/fontawesome.min.css" integrity="sha384-QYIZto+st3yW+o8+5OHfT6S482Zsvz2WfOzpFSXMF9zqeLcFV0/wlZpMtyFcZALm" crossorigin="anonymous">
     <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Customers</title>
</head>
<style>
</style>
<body id="page-top">
    <div class="header">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">
        <a class="navbar-brand" href="main.php">Content</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Services</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Contact</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

        <div class="container-fluid mt-2 mx-5">
            <h1>Welcome to De Box Website</h1>
            <p>This is the main content of your web page.</p>
        </div>
    </div>

    <?php
    if(isset($_SESSION['status'])){
        ?>
            <div class="alert alert-dismissible mx-3 my-3" style="background-color:#fefaf9">
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                <strong>Hey !</strong> <?php echo $_SESSION['status']; ?>
            </div>
        <?php
        unset($_SESSION['status']);

    }
    ?>

<div class="container-fluid my-5 px-5">
    <div class="container-fluid d-flex justify-content-end ">
    <a href="form.php"><button class="btn btn-primary mb-lg-3 mb-sm-2" >Add Customers</button></a>
    </div>
    <div class="container-fluid pb-5 " style="margin-bottom: 180px;">
        <div class="row">
            <div class="col-md-12">
                <div class="card bg-white">
                <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Content</h6>
                    </div>
                    <div class="card-header overflow-auto bg-white">
                       <table class=" bg-white table table-bordered table-hover" id="dataTable">
                        <thead>
                            <tr class="text-capitalize">
                                <th>image</th>
                                <th>title</th>
                                <th>desc</th>
                                <th>last updated</th>
                                <th>action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        $select= "SELECT * FROM `form`";
                        $sql= mysqli_query($conn, $select);
                         while($result= mysqli_fetch_assoc($sql)
                            ){
                             ?>
                        <tr>
                
                            <td class="px-5"><img src="<?php echo $result['image'];?>" width="100" hight="50"></td>
                            <td><?php echo $result['title'];?></td>
                            <td><?php echo $result['description'];?></td>
                            <td><?php echo date("j F, Y g:i:s A", strtotime($result['last_updated'])); ?></td>

                            <td><div class="dropdown dropstart">
                                <a href="#" class="text-muted" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false"><box-icon name='dots-vertical-rounded'></box-icon></a>
                                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <li>
                                        <a class="dropdown-item d-flex align-items-center " href="edit_form.php?ids=<?php echo $result['id'];?>" value=""><box-icon name='edit-alt' class="mx-2"></box-icon>Edit</a>
                                    </li>
                                    <li>
                                        <button type="button" class="dropdown-item d-flex align-items-center id_click" value="<?php echo $result['id'];?>"><box-icon name='trash' class="mx-2"></box-icon>Delete</button>
                                    </li> 
                                </ul>
                                </div>
                            </td>
                
                        </tr>
                            
                        <?php     
                        }
                        ?>
                        </tbody>
                       </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>


</body>

 <!-- Bootstrap core JavaScript-->
 <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>

    <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
        $(document).ready(function() {
            $(".id_click").click(function(event) {
                event.preventDefault();
                var id = $(this).val();
                console.log('id');
                if (confirm("Are you sure you want to delete?")) {
                     window.location.href = "delete_form.php?id=" + id;
                }else {
                    alert("canceled.");
                }
            });
        });
    </script>


    
</html>

