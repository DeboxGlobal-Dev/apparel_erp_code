<?php 
include("db.php");
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.2.1/css/fontawesome.min.css" integrity="sha384-QYIZto+st3yW+o8+5OHfT6S482Zsvz2WfOzpFSXMF9zqeLcFV0/wlZpMtyFcZALm" crossorigin="anonymous">
     <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">


    
    <title>Content</title>
</head>
<style>
    .none{
        display: none;
    }
</style>

<body id="page-top">
    <div class="header">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">
        <a class="navbar-brand" href="main.php">Content</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Services</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Contact</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
    </div>
<div class="container my-5">
    <form class="border border-2 shadow mb-5" actiom="" method="POST" enctype="multipart/form-data">
    <?php
         $updateid= $_GET['ids'];
         $emailquery= "SELECT * from `form` where id=$updateid";
         $query = mysqli_query($conn, $emailquery); 
         $user = mysqli_fetch_assoc($query);
        
        ?>
        <div class="row m-4">
            <div  class="col-sm-12 col-lg-4  col-md-6 my-2">
                <label class="form-label text-dark">Image</label>
                <input type="file" class="form-control" aria-describedby="emailHelp" name="image" placeholder="Image" required>
                <div id="emailHelp" class="form-text"></div>
            </div>
            <div class="col-sm-12 col-lg-4  col-md-6 my-2">
            <label class="form-label text-dark">Title</label>
            <input type="text" class="form-control" aria-describedby="emailHelp" name="title" placeholder="Title" required value="<?php echo $user['title'];?>">
            <div id="emailHelp" class="form-text"></div>
            </div>
            <div class="col-sm-12 col-lg-6  col-md-6 my-2">
                <label for="" class="form-label text-dark">Description</label>
                <textarea class="form-control"  rows="3" name="long_desc"><?php echo $user['description'];?></textarea>
            </div>
        </div>
           
            <div class="btn d-flex justify-content-between ">
            <div class="mb-4 mx-4 pe-3">
                <a href="content.php" class="btn text-white mx-2" style="background-color: #d70d38;">Cancel</a>
                <button type="submit" class="btn btn-primary" name="submit">Submit</button>
            </div>
            </div>
    </form>
</div>


<div class="footer">
   
</div>
</body>

 <!-- Bootstrap core JavaScript-->
 <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>
    <script src="https://unpkg.com/boxicons@2.1.4/dist/boxicons.js"></script>

</html>

<?php

if(isset($_POST["submit"])){
    $update =$_GET['ids'];
    $title = $_POST["title"];
    $long_desc = $_POST["long_desc"];
    $content_image = $_FILES["image"];
   

    $filename = $content_image["name"];
    $filepath = $content_image["tmp_name"];
    $fileerror = $content_image["error"];
    date_default_timezone_set('asia/kolkata');
    $last_updated = date('y-m-d h:i:s');

    if($fileerror == 0){
        $disfile = 'uplode_file/'.$filename;
        move_uploaded_file($filepath, $disfile);
        
$sql ="UPDATE `form` SET `image`='$disfile',`title`='$title',`description`='$long_desc',`last_updated`='$last_updated' WHERE id= $update";
$result =  mysqli_query($conn, $sql);
if($result){
   $_SESSION['status']="Data update successfuly";
   ?>
   <script>
    window.location.href="main.php";
   </script>
   
   <?php
}else{
    echo $conn->error;
}
} else {
    echo "Error uploading file.";
}

}

?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function () {
        $('#changeClass').change(function(){
            var selectedValue = $(this).val();

            if (selectedValue == "Learning_path") {
                $('#hidelink').addClass("none");
            }else if (selectedValue == "General_resource") {
                $('#hidelink').removeClass('none');
            }

        });
    });
</script>